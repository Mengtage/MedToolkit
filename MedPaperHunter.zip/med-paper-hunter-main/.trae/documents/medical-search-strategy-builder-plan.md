# Medical Search Strategy Builder 模块实现计划

**版本**: 1.0
**创建日期**: 2026-05-16
**目标**: 将 medical-search-strategy-builder 技能转化为可集成的 Python 模块

---

## 目录

1. [概述](#概述)
2. [架构设计](#架构设计)
3. [后端模块实现](#后端模块实现)
4. [API 接口设计](#api-接口设计)
5. [前端组件设计](#前端组件设计)
6. [数据流](#数据流)
7. [实现步骤](#实现步骤)
8. [验收标准](#验收标准)

---

## 概述

### 项目背景

MedPaperHunter 是一个医学文献检索系统，用户通过自然语言输入研究问题，系统自动生成多数据库检索式。用户反馈现有流程过于自动化，缺乏对生成结果的编辑能力。

### 需求分析

| 用户需求 | 优先级 | 当前状态 | 目标状态 |
|---------|--------|---------|---------|
| 自然语言输入 | P0 | 支持 | 保持 |
| PICO/PEO 分解 | P0 | LLM 自动 | LLM 自动 + 用户编辑 |
| 检索式生成 | P0 | 固定模板 | 多数据库适配模板 |
| 结果预览 | P1 | 有限 | 完全可编辑预览 |
| 中英双语 | P1 | 部分 | 完整支持 |

### 设计原则

基于 Vercel React Best Practices 和 Composition Patterns:

1. **组件化设计**: 遵循 compound components 模式，避免 boolean prop 泛滥
2. **状态管理**: 状态与实现解耦，通过 Context 提供依赖注入
3. **性能优化**: 消除瀑布流请求，使用 Promise.all 并行获取
4. **可维护性**: 小而专注的模块，清晰的接口边界

---

## 架构设计

### 整体架构

```
┌─────────────────────────────────────────────────────────────────┐
│                         前端 (index.html)                        │
├─────────────────────────────────────────────────────────────────┤
│  Step 1: 输入研究问题                                             │
│      ↓                                                           │
│  Step 2: PICO 分解预览 & 编辑                                      │
│      ↓                                                           │
│  Step 3: 检索式预览 & 编辑                                         │
│      ↓                                                           │
│  Step 4: 执行检索                                                 │
│      ↓                                                           │
│  Step 5: 结果处理 & 导出                                           │
└─────────────────────────────────────────────────────────────────┘
                              ↓ ↑
┌─────────────────────────────────────────────────────────────────┐
│                     FastAPI 后端 (app.py)                         │
├─────────────────────────────────────────────────────────────────┤
│  POST /api/search/analyze    → LLM 分析 + PICO 分解               │
│  POST /api/search/build      → 基于 PICO 生成检索式                 │
│  POST /api/search/strategy   → 保留的快速端点                      │
│  POST /api/search/execute    → 执行多数据库检索                     │
└─────────────────────────────────────────────────────────────────┘
                              ↓ ↑
┌─────────────────────────────────────────────────────────────────┐
│              模块 (medical_search_strategy_builder.py)            │
├─────────────────────────────────────────────────────────────────┤
│  ├── 框架检测 (PICO/PEO)                                         │
│  ├── 概念提取与扩展                                                │
│  ├── 同义词库                                                     │
│  ├── MeSH 主题词                                                 │
│  ├── 截词规则                                                    │
│  └── 多数据库检索式生成                                            │
└─────────────────────────────────────────────────────────────────┘
                              ↓ ↑
┌─────────────────────────────────────────────────────────────────┐
│                    外部服务 (LLM + 数据库 API)                     │
├─────────────────────────────────────────────────────────────────┤
│  ├── DeepSeek API (LLM 分析)                                     │
│  ├── PubMed E-utilities (MeSH 校验)                              │
│  └── 各数据库检索接口                                             │
└─────────────────────────────────────────────────────────────────┘
```

### 模块结构

```
backend/
├── medical_search_strategy_builder.py   # 核心模块 (扩展)
│   ├── Framework (Enum)                # PICO / PEO
│   ├── Database (Enum)                  # pubmed, embase, etc.
│   ├── Concept (Dataclass)              # 概念数据模型
│   ├── BuildResult (Dataclass)          # 构建结果
│   ├── MedicalSearchStrategyBuilder     # 主类
│   │   ├── detect_language()            # 语言检测
│   │   ├── suggest_framework()          # 框架建议
│   │   ├── build()                      # 核心构建方法
│   │   ├── build_from_concept_names()   # 简化构建
│   │   ├── lookup_mesh()                # MeSH 查找
│   │   ├── to_markdown()               # Markdown 输出
│   │   └── to_dict()                   # JSON 输出
│   └── _DATABASE_GENERATORS             # 各数据库生成器
│
├── llm_medical_search.py                # LLM 集成层 (已有)
│   ├── LLMClient                        # LLM API 客户端
│   ├── MeSHValidator                    # MeSH 校验器
│   └── LLMedicalSearchBuilder           # LLM 驱动构建器
│
└── app.py                              # FastAPI 应用 (扩展)
    ├── POST /api/search/analyze         # 新增: 分析端点
    ├── POST /api/search/build           # 新增: 构建端点
    └── POST /api/search/strategy       # 保留: 快速端点
```

---

## 后端模块实现

### 1. 数据模型扩展

```python
# medical_search_strategy_builder.py 扩展

@dataclass
class Concept:
    """代表 PICO/PEO 中的一个核心概念。"""
    dimension: str              # P / I / C / O / E
    name: str                   # 概念名称 (英文)
    mesh: list[str] = field(default_factory=list)       # MeSH/Emtree 主题词
    free_text: list[str] = field(default_factory=list)  # 自由词
    truncated: list[str] = field(default_factory=list)  # 截词变体

    def all_terms(self) -> list[str]:
        """返回所有检索词（去重）。"""
        ...

@dataclass
class PICOAnalysis:
    """LLM 分析结果的数据模型。"""
    framework: Framework
    research_type: str
    concepts: list[Concept]
    language: str = "en"
    english_question: Optional[str] = None

@dataclass
class BuildResult:
    """检索式构建结果。"""
    question: str
    framework: str
    research_type: str
    concepts: list[dict]
    strategies: dict[str, str]
    validation_tips: list[str]
    language: str = "en"
```

### 2. 核心类扩展

```python
class MedicalSearchStrategyBuilder:
    """医学文献检索式构建器。"""

    def __init__(self):
        self._mesh_lookup = COMMON_MESH_TERMS
        self._synonym_db = SYNONYM_DATABASE  # 新增: 同义词库

    def analyze_question(self, question: str) -> PICOAnalysis:
        """分析研究问题，返回 PICO 结构。"""
        language = self.detect_language(question)
        framework = self.suggest_framework(question)

        # 调用 LLM 分析 (由调用者注入)
        ...

    def build(
        self,
        question: str,
        concepts: dict[str, dict],
        framework: str = "PICO",
        databases: Optional[list[str]] = None,
    ) -> BuildResult:
        """核心方法：根据概念生成检索式。"""
        ...

    def generate_strategy(
        self,
        concept: Concept,
        database: Database,
    ) -> str:
        """为单个概念生成指定数据库的检索式。"""
        ...
```

### 3. 数据库生成器

每个数据库生成器遵循统一的接口：

```python
def _generate_pubmed(concepts: list[Concept]) -> str:
    """PubMed 检索式生成器。"""
    # MeSH 主题词 + 自由词组合
    # 使用 [MeSH Terms] 和 [Title/Abstract] 字段限定
    ...

def _generate_embase(concepts: list[Concept]) -> str:
    """Embase 检索式生成器。"""
    # Emtree 主题词 + :ti,ab 字段限定
    # 支持 NEAR/N NEXT/N 邻近算符
    ...

def _generate_cochrane(concepts: list[Concept]) -> str:
    """Cochrane 检索式生成器。"""
    # Search Manager 格式
    # MeSH descriptor + 自由词组合
    ...

def _generate_wos(concepts: list[Concept]) -> str:
    """Web of Science 检索式生成器。"""
    # TS= 主题搜索
    # 支持截词和邻近算符
    ...

def _generate_arxiv(concepts: list[Concept]) -> str:
    """arXiv 检索式生成器。"""
    # ti:, abs:, cat: 字段搜索
    ...
```

---

## API 接口设计

### 请求/响应模型

```python
# 请求模型
class AnalyzeRequest(BaseModel):
    question: str = Field(..., description="自然语言研究问题")
    language: Optional[str] = Field(None, description="强制指定语言 (zh/en)")


class BuildRequest(BaseModel):
    concepts: dict[str, dict] = Field(..., description="PICO 概念字典")
    framework: str = Field("PICO", description="框架类型")
    databases: list[str] = Field(
        default=["pubmed", "embase", "cochrane", "wos", "arxiv"],
        description="目标数据库"
    )


class StrategyRequest(BaseModel):
    question: str = Field(..., description="自然语言研究问题")
    databases: list[str] = Field(
        default=["pubmed", "embase", "cochrane", "wos"],
        description="目标数据库"
    )
    date_range: str = Field("", description="日期范围")

# 响应模型
class AnalyzeResponse(BaseModel):
    framework: str
    research_type: str
    concepts: dict[str, dict]
    language: str
    english_question: Optional[str] = None


class BuildResponse(BaseModel):
    strategies: dict[str, str]
    validation_tips: list[str]
    language: str
```

### API 端点

| 端点 | 方法 | 功能 | 输入 | 输出 |
|------|------|------|------|------|
| `/api/search/analyze` | POST | LLM 分析 + PICO 分解 | question | PICO 结构 |
| `/api/search/build` | POST | 基于 PICO 生成检索式 | concepts, framework | 检索式 |
| `/api/search/strategy` | POST | 快速端点 (end-to-end) | question | 检索式 |
| `/api/search/validate-mesh` | POST | 校验 MeSH 词 | terms | 校验结果 |

### API 调用流程

```python
# 前端 → 后端 API 调用

# Step 1: 分析研究问题
POST /api/search/analyze
Body: {"question": "二甲双胍对比GLP-1治疗2型糖尿病的有效性"}
Response: {
    "framework": "PICO",
    "research_type": "interventional/therapeutic",
    "concepts": {
        "P": {"name": "Type 2 Diabetes", "mesh": [...], "free_text": [...]},
        "I": {"name": "GLP-1 Receptor Agonists", "mesh": [...], "free_text": [...]},
        "C": {"name": "Metformin", "mesh": [...], "free_text": [...]}
    },
    "language": "zh",
    "english_question": "Efficacy of GLP-1 vs Metformin in T2D"
}

# Step 2: 用户编辑后提交构建
POST /api/search/build
Body: {
    "concepts": {...},  # 用户可能已修改
    "framework": "PICO",
    "databases": ["pubmed", "embase", "cochrane"]
}
Response: {
    "strategies": {
        "pubmed": "(#P) AND (#I) AND (#C)",
        "embase": "#1 AND #2 AND #3",
        ...
    },
    "validation_tips": [...],
    "language": "zh"
}

# Step 3: 用户确认后执行 (复用现有端点)
POST /api/search/execute
```

---

## 前端组件设计

### 组件架构 (Composition Pattern)

遵循 **Compound Components** 模式，将复杂表单拆分为可组合的小组件：

```
<SearchWorkflow>
    <ResearchQuestionInput />
    <DatabaseSelector />
    <DateRangePicker />
    <PICOPreview>
        <ConceptEditor dimension="P" />
        <ConceptEditor dimension="I" />
        <ConceptEditor dimension="C" />
        <ConceptEditor dimension="O" />
    </PICOPreview>
    <StrategyPreview>
        <StrategyEditor database="pubmed" />
        <StrategyEditor database="embase" />
    </StrategyPreview>
    <ExecutionStatus />
    <ResultsTable />
    <ExportActions />
</SearchWorkflow>
```

### 状态管理

使用 **Context Provider** 模式管理跨组件状态：

```javascript
// 状态上下文
const WorkflowContext = React.createContext();

function WorkflowProvider({ children }) {
    const [state, setState] = useState({
        // 流程状态
        currentStep: 1,
        isLoading: false,

        // 数据
        question: '',
        selectedDatabases: ['pubmed'],
        dateRange: { start: '', end: '' },

        // 分析结果
        analysis: null,
        concepts: {},

        // 构建结果
        strategies: {},

        // 检索结果
        articles: [],
    });

    const actions = {
        setQuestion: (q) => setState(s => ({...s, question: q})),
        setConcepts: (c) => setState(s => ({...s, concepts: c})),
        setStrategies: (s) => setState(s => ({...s, strategies: s})),
        nextStep: () => setState(s => ({...s, currentStep: s.currentStep + 1})),
        prevStep: () => setState(s => ({...s, currentStep: s.currentStep - 1})),
    };

    return (
        <WorkflowContext.Provider value={{ state, actions }}>
            {children}
        </WorkflowContext.Provider>
    );
}
```

### 性能优化 (React Best Practices)

1. **消除瀑布流**: 使用 Promise.all 并行调用 analyze 和 validate
2. **组件懒加载**: 复杂编辑器组件使用动态导入
3. **状态派生**: 使用 useMemo 计算派生状态，避免重复计算
4. **事件防抖**: 搜索输入使用 debounce 减少 API 调用

```javascript
// 性能优化示例
async function analyzeQuestion() {
    setLoading(true);

    // 并行执行：LLM 分析 + MeSH 预校验
    const [analysis, meshValidation] = await Promise.all([
        api.analyze(question),
        api.preValidateMesh(getMeshTerms(question)),
    ]);

    setState({ analysis, meshValidation });
    setLoading(false);
}

// 防抖输入
const debouncedAnalyze = useDebouncedCallback(analyze, 500);
```

### 步骤流程设计

```
Step 1: 研究问题输入
┌─────────────────────────────────────────┐
│  研究问题: [文本输入框]                    │
│  数据库:   ☑ PubMed ☐ Embase ☐ Cochrane │
│  日期范围: [开始] - [结束]                 │
│  [生成检索式]                             │
└─────────────────────────────────────────┘

Step 2: PICO 分解预览 & 编辑
┌─────────────────────────────────────────┐
│  框架: PICO | 研究类型: 干预性/治疗性      │
├─────────────────────────────────────────┤
│  P (人群): Type 2 Diabetes              │
│    MeSH: [Diabetes Mellitus, Type 2]    │
│    自由词: [type 2 diabetes, T2DM, ...] │
│    [添加] [删除]                          │
├─────────────────────────────────────────┤
│  I (干预): GLP-1 Receptor Agonists      │
│    ...                                  │
├─────────────────────────────────────────┤
│  C (对照): Metformin                    │
│    ...                                  │
├─────────────────────────────────────────┤
│  [上一步] [下一步: 生成检索式]             │
└─────────────────────────────────────────┘

Step 3: 检索式预览 & 编辑
┌─────────────────────────────────────────┐
│  PubMed 检索式:                          │
│  ┌─────────────────────────────────────┐│
│  │ #P ("Diabetes Mellitus, Type 2"[MeSH]││
│  │   OR "type 2 diabetes"[Title/Ab...]) ││
│  │ AND ...                              ││
│  └─────────────────────────────────────┘│
│  [编辑] [复制]                           │
├─────────────────────────────────────────┤
│  Embase 检索式: ...                      │
├─────────────────────────────────────────┤
│  [上一步] [下一步: 执行检索]              │
└─────────────────────────────────────────┘

Step 4: 执行检索 (复用现有)
┌─────────────────────────────────────────┐
│  PubMed: 检索中... ✓ 234 篇             │
│  Embase: 检索中... ✓ 156 篇             │
│  [跳过，直接进入下一步]                   │
└─────────────────────────────────────────┘

Step 5: 结果 & 导出 (复用现有)
┌─────────────────────────────────────────┐
│  总计: 390 篇 | 去重后: 356 篇           │
│  [去重] [AI 筛选] [导出]                 │
└─────────────────────────────────────────┘
```

---

## 数据流

### 完整数据流

```
用户输入研究问题
      │
      ▼
┌─────────────────┐
│ 前端状态初始化    │
│ question: ...    │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ POST /analyze   │ ←── LLM 分析 + PICO 分解
│                  │
│ 请求:            │
│ {question: ...}  │
│                  │
│ 响应:            │
│ {               │
│   framework,    │
│   concepts,     │
│   language      │
│ }               │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ 用户编辑 PICO   │ ←── 可选：用户修改概念
│ concepts: {...} │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ POST /build     │ ←── 生成多数据库检索式
│                  │
│ 请求:            │
│ {               │
│   concepts,     │
│   framework,    │
│   databases     │
│ }               │
│                  │
│ 响应:            │
│ {               │
│   strategies,   │
│   validation_   │
│   tips          │
│ }               │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ 用户编辑检索式   │ ←── 可选：用户修改检索式
│ strategies: {}  │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ POST /execute   │ ←── 执行多数据库检索
│                  │
│ 响应:            │
│ {               │
│   articles,     │
│   counts        │
│ }               │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ 去重 + AI 筛选  │
│ (复用现有逻辑)   │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ 导出结果        │
│ (复用现有逻辑)   │
└─────────────────┘
```

---

## 实现步骤

### Phase 1: 后端模块扩展 (1-2 天)

| 任务 | 描述 | 优先级 |
|------|------|--------|
| 1.1 | 扩展 Concept 数据模型，添加验证方法 | P0 |
| 1.2 | 扩展 MedicalSearchStrategyBuilder 类 | P0 |
| 1.3 | 实现各数据库检索式生成器 | P0 |
| 1.4 | 添加同义词库和 MeSH 扩展表 | P1 |
| 1.5 | 添加中文支持的术语翻译辅助 | P1 |
| 1.6 | 单元测试覆盖 | P2 |

### Phase 2: API 端点扩展 (0.5 天)

| 任务 | 描述 | 优先级 |
|------|------|--------|
| 2.1 | 添加 /api/search/analyze 端点 | P0 |
| 2.2 | 添加 /api/search/build 端点 | P0 |
| 2.3 | 更新请求/响应模型 | P0 |
| 2.4 | API 文档更新 | P1 |

### Phase 3: 前端流程扩展 (2-3 天)

| 任务 | 描述 | 优先级 |
|------|------|--------|
| 3.1 | 重构前端状态管理，添加 WorkflowContext | P0 |
| 3.2 | 实现 PICO 编辑器组件 | P0 |
| 3.3 | 实现检索式编辑器组件 | P0 |
| 3.4 | 添加步骤导航和进度显示 | P1 |
| 3.5 | 添加加载状态和错误处理 | P1 |
| 3.6 | 响应式适配优化 | P2 |

### Phase 4: 集成测试 (0.5 天)

| 任务 | 描述 | 优先级 |
|------|------|--------|
| 4.1 | 端到端流程测试 | P0 |
| 4.2 | 边界情况测试 (空输入、特殊字符等) | P1 |
| 4.3 | 性能测试 (大批量概念) | P2 |

---

## 验收标准

### 功能验收

- [ ] 用户可以输入自然语言研究问题
- [ ] 系统自动进行 PICO/PEO 分解并展示
- [ ] 用户可以编辑任意维度的概念
- [ ] 用户可以编辑生成的检索式
- [ ] 支持 PubMed、Embase、Cochrane、WoS、arXiv 五个数据库
- [ ] 中英文输入均可正确处理

### 性能验收

- [ ] LLM 分析响应时间 < 10 秒
- [ ] 检索式生成响应时间 < 1 秒
- [ ] 前端交互无明显卡顿

### 质量验收

- [ ] API 响应格式统一
- [ ] 错误信息清晰易懂
- [ ] 代码符合 PEP 8 规范
- [ ] 关键函数有文档字符串

---

## 附录

### A. 参考资料

1. [PubMed E-utilities API](https://eutils.ncbi.nlm.nih.gov/entrez/eutils/)
2. [Cochrane Search Manager Syntax](https://www.cochranelibrary.com/help-and-support/tools-and-resources)
3. [Embase Search Syntax](https://www.elsevier.com/solutions/embase-biomedical-research)
4. [Web of Science Search Operators](https://images.webofknowledge.com/WOKRS60B4/help/WOS/hs_search_operators.html)

### B. 技术债务

- 当前前端使用原生 JavaScript，建议后续迁移到 React
- LLM 调用未实现重试机制
- MeSH 校验缓存机制待优化

### C. 未来扩展

- 添加检索式优化建议 (基于结果数量反馈)
- 支持更多数据库 (ClinicalTrials.gov, CNKI 等)
- 添加检索式历史记录功能
- 导出 PRISMA 流程图

---

**文档版本**: 1.0
**下次审查日期**: 实现完成后
**维护者**: 开发团队
