# MedPaperHunter 项目修复规范

## 一、项目背景与目标回顾

### 1.1 项目核心目标
构建一个**医学文献智能检索系统**，通过 Web 界面帮助医学研究者和学生：
- 将自然语言研究问题转化为专业检索式
- 在多个数据库（PubMed、Embase、Cochrane、WOS、arXiv）进行检索
- 自动去重和 AI 筛选相关文献
- 导出标准化结果

### 1.2 当前系统架构
```
用户界面 (Web UI)
    ↓
FastAPI 后端服务
    ├── 检索式生成模块 (LLM + MeSH API)
    ├── PubMed 检索 (E-utilities API)
    ├── WoS/Embase 检索 (CARSI Session)
    ├── 文献去重模块
    └── 导出模块
```

---

## 二、当前问题诊断

### 2.1 问题 1：执行检索时 422 错误

**错误现象**：
```
INFO: 127.0.0.1:58203 - "POST /api/search/execute HTTP/1.1" 422 Unprocessable Content
```

**根本原因**：
前端发送的 `ExecuteRequest` 数据格式与后端 Pydantic 模型不匹配。

**需要检查的数据结构**：
```python
class ExecuteRequest(BaseModel):
    strategies: dict[str, str]  # 数据库名称 → 检索式
    databases: list[str]        # 要检索的数据库列表
    date_range: str = ""       # 日期范围
    max_results: int = 500     # 最大结果数
```

**修复方案**：
检查前端 JavaScript 的 `executeSearch()` 函数，确保发送的 JSON 格式正确。

---

### 2.2 问题 2：CARSI 认证机制

**当前实现**：
```python
# web_fetcher.py 中的 CARSISession
- 需要 CARSI_URL, CARSI_USERNAME, CARSI_PASSWORD
- 通过 httpx 模拟登录流程
```

**问题分析**：
1. 大多数用户的机构不提供 CARSI 账号密码登录
2. CARSI 主要用于 Shibboleth 单点登录，无法通过简单账号密码实现
3. 当前实现会阻塞不配置 CARSI 的用户

**建议方案**：
1. 将 WoS/Embase 检索改为**可选功能**
2. 如果未配置 CARSI，显示友好提示并建议手动导出 CSV 导入
3. 添加详细文档说明 CARSI 的实际使用方式

---

### 2.3 问题 3：检索式生成模块局限性

**根据医学检索最佳实践分析**：

#### 3.1 当前实现的优点
- ✅ 使用 LLM 分析自然语言问题
- ✅ 调用 MeSH API 验证医学术语
- ✅ 生成多数据库检索式

#### 3.2 当前实现的局限性

| 问题 | 描述 | 影响 |
|------|------|------|
| **缺乏 PICO/PEO 分析** | 直接生成检索式，未分解研究问题结构 | 检索式可能遗漏重要概念 |
| **同义词扩展不足** | 依赖 LLM 生成同义词，可能遗漏关键术语 | 召回率降低 |
| **自由词与主题词组合** | 组合方式可能不够规范 | 检索结果不准确 |
| **截词符使用** | 可能过度使用或使用不当 | 结果过多或过少 |
| **限定词缺失** | 缺少时间、语言、文献类型限制选项 | 结果相关性不高 |

#### 3.3 改进方向

**短期改进**：
1. 添加检索式预览和手动编辑功能
2. 显示检索式各部分含义解释
3. 提供常见限定词快速选择

**长期改进**（需要用户确认）：
1. 添加结构化 PICO 输入界面
2. 提供同义词库辅助扩展
3. 支持检索式导入/导出

---

## 三、修复计划

### 阶段 1：紧急修复 - 让系统能运行

#### 任务 1.1：修复 422 错误
- [ ] 检查前端发送的数据格式
- [ ] 验证后端 Pydantic 模型定义
- [ ] 添加请求日志便于调试
- [ ] 测试完整的检索流程

#### 任务 1.2：优化 CARSI 逻辑
- [ ] 将 WoS/Embase 改为可选检索
- [ ] 未配置时显示友好提示
- [ ] 确保不配置 CARSI 也能使用 PubMed 检索

### 阶段 2：用户体验改进

#### 任务 2.1：前端交互优化
- [ ] 添加加载状态提示
- [ ] 改进错误信息显示
- [ ] 添加数据库选择界面

#### 任务 2.2：检索过程可视化
- [ ] 显示每个数据库的检索进度
- [ ] 展示各数据库返回的结果数量
- [ ] 支持中断检索操作

### 阶段 3：检索质量提升（可选）

#### 任务 3.1：添加 PICO 辅助输入
- [ ] 提供结构化研究问题输入
- [ ] 生成检索式时显示分析过程

#### 任务 3.2：检索式编辑功能
- [ ] 支持手动修改检索式
- [ ] 提供检索式语法提示

---

## 四、技术方案

### 4.1 后端修改

#### 文件：`backend/app.py`
```python
# ExecuteRequest 模型保持不变，但添加更详细的日志

@app.post("/api/search/execute")
async def execute_search(request: ExecuteRequest):
    # 添加请求日志
    logger.info(f"Received execute request: databases={request.databases}")
    logger.info(f"Strategies: {request.strategies}")
    # ...
```

#### 文件：`backend/web_fetcher.py`
```python
# 改进 CARSI 逻辑

class CARSISession:
    def __init__(self, ...):
        # 检查是否配置
        self.enabled = all([carsi_url, username, password])

    async def fetch_wos(self, ...):
        if not self.enabled:
            logger.warning("CARSI not configured, WoS search skipped")
            return []  # 返回空列表而不是报错
```

### 4.2 前端修改

#### 文件：`frontend/index.html`
```javascript
// 修复 executeSearch 函数

async function executeSearch() {
    // 获取选中的数据库
    const databases = Array.from(document.querySelectorAll('input[name="db"]:checked'))
        .map(cb => cb.value);

    // 构建请求数据
    const strategies = {};
    databases.forEach(db => {
        strategies[db] = document.getElementById(`strategy-${db}`)?.value || '';
    });

    const requestData = {
        strategies: strategies,
        databases: databases,
        date_range: document.getElementById('dateRange')?.value || '',
        max_results: parseInt(document.getElementById('maxResults')?.value) || 500
    };

    // 发送请求
    const response = await fetch('/api/search/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
    });

    // 处理响应...
}
```

---

## 五、测试计划

### 5.1 功能测试用例

| 测试场景 | 预期结果 |
|---------|---------|
| 仅选择 PubMed，不配置 CARSI | 成功检索并显示结果 |
| 选择 PubMed + WoS，不配置 CARSI | PubMed 成功，WoS 跳过并提示 |
| 输入中文研究问题 | 生成英文检索式 |
| 输入英文研究问题 | 生成对应检索式 |
| 检索结果去重 | 去除重复文献 |
| 导出为 Excel | 生成包含完整信息的 Excel 文件 |

### 5.2 边界测试

| 场景 | 预期处理 |
|------|---------|
| 不输入研究问题直接生成 | 显示验证错误提示 |
| 输入空检索式执行 | 显示友好错误信息 |
| 网络超时 | 显示超时提示，可重试 |
| LLM API 不可用 | 使用模板生成基础检索式 |

---

## 六、风险评估

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| CARSI 实现复杂 | 高 | 改为可选功能，降低预期 |
| LLM API 费用 | 中 | 设置合理的请求限制 |
| MeSH API 限流 | 低 | 添加缓存和重试机制 |
| 前端兼容性问题 | 中 | 测试主流浏览器 |

---

## 七、用户须知

### 7.1 使用前提
- Python 3.8+
- DeepSeek API Key（用于生成检索式）
- 网络连接（访问 PubMed/MeSH API）

### 7.2 CARSI 配置说明
**重要**：CARSI 认证通常需要机构提供，不是简单的账号密码登录。

**不配置 CARSI 的影响**：
- WoS 和 Embase 需要手动导出 CSV 导入
- PubMed 检索不受影响 ✅

**如需配置 WoS/Embase 自动检索**：
1. 联系您所在机构的图书馆
2. 确认是否支持 CARSI/Shibboleth 认证
3. 获取相应的认证信息

---

## 八、后续规划

### 8.1 可选增强功能
1. **检索历史记录** - 保存用户之前的检索
2. **结果收藏** - 标记重要文献
3. **定时任务** - 自动执行定期检索
4. **协作功能** - 多用户共享检索结果

### 8.2 需要用户反馈
1. 当前的检索式质量是否满足需求？
2. 是否需要添加其他数据库支持？
3. 界面的交互方式是否需要改进？
