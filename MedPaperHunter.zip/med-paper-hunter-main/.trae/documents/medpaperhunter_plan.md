
# MedPaperHunter Project Integration Plan

## Overview
We have two projects merged into one directory. The first project (MedPaperHunter module) is superior with a clean FastAPI backend, modular components, and a polished frontend. We will organize it properly and clean up redundant files.

## Step 1: Directory Structure Organization

Create a clean project structure:

```
/workspace/
├── backend/
│   ├── app.py
│   ├── medical_search_strategy_builder.py
│   ├── llm_medical_search.py
│   ├── pubmed_fetcher.py
│   ├── web_fetcher.py
│   ├── dedup.py
│   └── exporter.py
├── frontend/
│   └── index.html
├── data/
│   └── impact_factors.csv
├── output/
├── .env.example
├── requirements.txt
├── README.md
└── .gitignore
```

## Step 2: Update requirements.txt

Update requirements.txt with all necessary dependencies:
- fastapi
- uvicorn
- httpx
- openpyxl
- python-dotenv
- (and any others needed)

## Step 3: Create .env.example

Create a .env.example file with the necessary environment variables:
- LLM_API_KEY
- LLM_BASE_URL
- LLM_MODEL
- CARSI_URL
- CARSI_USERNAME
- CARSI_PASSWORD
- OUTPUT_DIR

## Step 4: Clean Up Redundant Files

Remove redundant files from the second project that are no longer needed.

## Step 5: Test the Application

Run the backend and test the application to make sure everything works.
